<template>
  <div>
    <B2bForm />
  </div>
</template>
<script>
import B2bForm from "@/components/pages/B2bForm.vue";
export default {
  components: {
    B2bForm,
  },
};
</script>