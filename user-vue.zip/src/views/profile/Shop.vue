<template>
  <h1>shop</h1>
</template>

<script>
export default {};
</script>

<style>
</style>