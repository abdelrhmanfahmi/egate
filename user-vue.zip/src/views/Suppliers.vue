<template>
    <div>
        <h1>Suppliers</h1>
    </div>
</template>