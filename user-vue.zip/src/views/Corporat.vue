<template>
    <div>
        <h1>Corporat</h1>
    </div>
</template>