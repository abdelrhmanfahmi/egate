export default {
// nav
  home: "home",
  suppliers:"suppliers",
  about:"about",
  corporat:"corporat",
  contactUs:"contact us"
};
