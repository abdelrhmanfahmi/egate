export default {
  createCustomerAccount: "create customer account",
  mainInformation: "main information",
  alreadyHaveAccount: "Already have account",
  firstName: "first name",
  lastName: "last name",
  email: "email",
  password: "password",
  confirmPassword: "confirm password",
  countryCode: "country code",
  phone: "phone number",
  chooseOneOfTheWays: "Choose one of the ways to activate your account",
  PleaseReview: "Please review and agree to the",
  termsConditions: "Terms and Conditions",
  toCompleteTheRegistration: "to complete the registration process",
  subscribeTheNewsletter: "subscribe to the newsletter",
  submit: "Submit",
  unableRegister:
    " If you are unable to register, please contact us for assistance",
  registrationCompany:
    "registration for the accounts of restaurants, hotels and companies wholesale purchase",
    jobTitle:"job title"
};
