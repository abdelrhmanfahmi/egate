export default {
  login: "login",
  WelcomeAgain: "welcome again",
  fogetPassword: "Forgot Password ?",
  DontHave: "Don't have account ?",
  createAccount: "Create account",
  LoginSocial :"Login by social media",
  loginNav: "login",
};
