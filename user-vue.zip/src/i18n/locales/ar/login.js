export default {
  login: "دخول",
  WelcomeAgain: "مرحبا بك مجددا ",
  fogetPassword: "نسيت كلمة المرور ؟",
  DontHave: "ليس لديك حساب ؟",
  createAccount: "تسجيل حساب",
  LoginSocial: "الدخول للاشخاص",
  loginNav: "تسجيل الدخول",
};
