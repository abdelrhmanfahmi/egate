import register from "./register";
import home from "./home";
import login from "./login";

export default {
  register,
  home,
  login,
};
