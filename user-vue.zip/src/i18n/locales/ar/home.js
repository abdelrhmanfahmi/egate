export default {
  // nav
  home: "الرئيسية",
  suppliers: "الموردين",
  about: "عن الشركة",
  corporat: "تسجيل الشركات",
  contactUs: "اتصل بنا",
};
